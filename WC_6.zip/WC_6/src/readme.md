using json
the json structure would be

{
    "project_name": "project_name",
    "url_lists": [
        "url1",
        "url2",
        "url3"
    ],
}

create project folder
create dataset
create parquet file

run the crawler

    get the html
    parse the html
    save the data to parquet file

